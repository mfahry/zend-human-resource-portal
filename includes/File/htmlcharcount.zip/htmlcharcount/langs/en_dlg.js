tinyMCE.addI18n('en.htmlcharcount',{
chars: 'HTML chars',
remaining: 'HTML chars remaining'
});